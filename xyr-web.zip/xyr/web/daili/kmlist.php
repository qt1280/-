<?php
/**
 * 卡密列表
**/
$mod='blank';
include("../api.inc.php");
$title='商品列表';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
if($vip==1){
    $dljg=$rs['dl1'];
    $dljgs=$rs['dls1'];
}elseif($vip==2){
    $dljg=$rs['dl2'];
    $dljgs=$rs['dls2'];
}elseif($vip==3){
    $dljg=$rs['dl3'];
    $dljgs=$rs['dls3'];
}elseif($vip==0){
    $dljg=$rs['dl0'];
    $dljgs=$rs['dls0'];
    //exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
    $dljg=$rs['dl4'];
    $dljgs=$rs['dls4'];
}elseif($vip==5){
    $dljg=$rs['dl5'];
    $dljgs=$rs['dls5'];
}
//echo "<script language='javascript'>alert('推荐人：".$dlid."');</script>";
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            <p>
            <?php
                $row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
                $dlrmb=$row['rmb'];
                echo '当前拿货价格：'.$dljg.'元/天 + '.$dljgs.'元/GB，当前余额 '.$dlrmb.' 元'
            ?>
            </p>
            <br />

            <div class="row">
              <div class="col-sm-12">
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">
                          <?php
                            if(isset($_GET['kw'])) {
                                if($_GET['type']==1) {
                                    $sql=" `km`='{$_GET['kw']}'";
                                    $numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
                                    $con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个商品';
                                }elseif($_GET['type']==2) {
                                    $sql=" `user`='{$_GET['kw']}'";
                                    $numrows=$DB->count("SELECT count(*) from auth_kms WHERE{$sql}");
                                    $con='包含 '.$_GET['kw'].' 的共有 <b>'.$numrows.'</b> 个商品';
                                }
                            }else{
                                $numrows=$DB->count("SELECT count(*) from auth_kms WHERE daili=$dlid");
                                $sql=" 1";
                                $con='共拥有 <b>'.$numrows.'</b> 个商品';
                            }
                            echo $con;
                          ?>
                      </h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">


<?php
function getkm($len = 18)
{
    $str = "1234567890";
    $strlen = strlen($str);
    $randstr = "";
    for ($i = 0; $i < $len; $i++) {
        $randstr .= $str[mt_rand(0, $strlen - 1)];
    }
    return $randstr;
}

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='add'){
$kind=1;

$num=intval($_POST['num']);
$value=intval($_POST['value']);
$values=intval($_POST['values']);
$kmtype_id=intval($_POST['kmtype_id']);
if($num<=0){exit("<script language='javascript'>alert('生成失败，卡密数量必须大于0！');history.go(-1);</script>");}
if($value<=0){exit("<script language='javascript'>alert('生成失败，生成天数必须大于0！');history.go(-1);</script>");}
if($values<=0){exit("<script language='javascript'>alert('生成失败，流量必须大于0GB！');history.go(-1);</script>");}
$money = ($value*$dljg+$values*$dljgs)*$num;  
$money_name = ($value*$dljg+$values*$dljgs);
$rmb=$row['rmb']-$money;
if($rmb>=0){
    
}else{
    exit("<script language='javascript'>alert('生成失败，余额不足，请联系管理员充值！');history.go(-1);</script>");
}
$sql=$DB->query("update `auth_daili` set `rmb`='$rmb' where `id`=$dlid;");
if($sql){
    
}else{
    exit("<script language='javascript'>alert('扣款失败，请联系管理员！');history.go(-1);</script>");
}

echo "<div class='list-group list-group-minimal'><li class='list-group-item list-group-item-success'>成功生成以下商品</li>";
for ($i = 0; $i < $num; $i++) {
    $km=getkm(18);
    $sql=$DB->query("insert into `auth_kms` (`kind`,`daili`,`km`,`value`,`values`,`money`,`addtime`,`kmtype_id`) values ('".$kind."','".$dlid."','".$km."','".$value."','".$values."','".$money_name."','".$date."','".$kmtype_id."')");
    if($sql) {
        echo "<li class='list-group-item'>$km</li>";
    }
}

echo '<a href="./kmlist.php" class="list-group-item active"><i class="fa fa-mail-reply"></i> 返回商品列表</a>';
}
else
{

/*echo '<form action="kmlist.php?my=add" method="POST" class="form-inline validate">
<a href="search.php" class="btn btn-info">搜索用户</a>
<div class="form-group pull-right">
  <div class="form-group">
    <input type="text" class="form-control" name="num" placeholder="卡密数量" data-validate="required,number,min[1]"/>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="value" placeholder="使用天数"  data-validate="required,number,min[1]"/>
  </div>
  <div class="form-group">
    <input type="text" class="form-control" name="values" placeholder="流量（GB）"  data-validate="required,number,min[1]"/>
  </div>
  <button type="submit" class="btn btn-secondary btn-single">生成</button>
</div>
</form>';*/


?>

                      <div class="table-responsive">
                      
                          <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                              <thead>
                                  <tr>
                                        <th>序号</th>
                                        <th data-priority="1">卡密</th>
                                        <th data-priority="3">商品信息</th>
                                        <th data-priority="6">状态</th>
                                        <th data-priority="6">套餐ID</th>
                                        <th data-priority="6">添加时间</th>
                                        <th data-priority="6">使用时间</th>
                                  </tr>
                              </thead>
                              <tbody>
                                <?php
                                $pagesize=30;
                                $pages=intval($numrows/$pagesize);
                                if ($numrows%$pagesize)
                                {
                                 $pages++;
                                 }
                                if (isset($_GET['page'])){
                                $page=intval($_GET['page']);
                                }
                                else{
                                $page=1;
                                }
                                $offset=$pagesize*($page - 1);
                                $rs=$DB->query("SELECT * FROM auth_kms WHERE  daili='$dlid' and kind='1' order by id desc limit $offset,$pagesize");
                                //$rs=$DB->query("SELECT * FROM auth_kms WHERE daili=$dlid order by id desc limit $offset,$pagesize");
                                //$rs=$DB->query("SELECT * FROM auth_kms WHERE{$sql} order by id desc limit $offset,$pagesize");
                                while($res = $DB->fetch($rs))
                                {
                                if($res['isuse']==1) {
                                    $isuse='<span class="badge badge-info">使用者:'.$res['user'].'</span>';
                                } elseif($res['isuse']==0) {
                                    $isuse='<span class="badge badge-secondary">未使用</span>';
                                }
                                if($res['isuse']==1) {
                                    $del='<button class="btn btn-xs btn-gray disabled">已经使用</button>';
                                } elseif($res['isuse']==0) {
                                    $del='<a href="./kmlist.php?my=del&id='.$res['id'].'" class="btn btn-xs btn-danger" onclick="return confirm(\'你确实要删除此卡密吗？\');">删除</a>';
                                }
                                echo '<tr><td><b>'.$res['id'].'</b></td><td><b>'.$res['km'].'</b></td><td>'.$res['value'].'天/'.$res['values'].'GB/￥'.$res['money'].'</td><td>'.$isuse.'</td><td>'.$res['kmtype_id'].'</td><td>'.$res['addtime'].'</td><td>'.$res['usetime'].'</td></tr>';
                                }
                                ?>
                              </tbody>
                          </table>
                      
                      </div>

                        <?php
                        echo'<ul class="pagination">';
                        $first=1;
                        $prev=$page-1;
                        $next=$page+1;
                        $last=$pages;
                        if ($page>1)
                        {
                        echo '<li><a href="kmlist.php?page='.$first.$link.'">首页</a></li>';
                        echo '<li><a href="kmlist.php?page='.$prev.$link.'">&laquo;</a></li>';
                        } else {
                        echo '<li class="disabled"><a>首页</a></li>';
                        echo '<li class="disabled"><a>&laquo;</a></li>';
                        }
                        for ($i=1;$i<$page;$i++)
                        echo '<li><a href="kmlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                        echo '<li class="disabled"><a>'.$page.'</a></li>';
                        for ($i=$page+1;$i<=$pages;$i++)
                        echo '<li><a href="kmlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                        echo '';
                        if ($page<$pages)
                        {
                        echo '<li><a href="kmlist.php?page='.$next.$link.'">&raquo;</a></li>';
                        echo '<li><a href="kmlist.php?page='.$last.$link.'">尾页</a></li>';
                        } else {
                        echo '<li class="disabled"><a>&raquo;</a></li>';
                        echo '<li class="disabled"><a>尾页</a></li>';
                        }
                        echo'</ul>';
                        #分页
                        }
                        ?>
                      
                    </div>
                  
                  </div>
              </div>
            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<?php