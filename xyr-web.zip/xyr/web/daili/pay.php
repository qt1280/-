<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索卡密';
$dlid=$_SESSION['dlid'];
$id = $_GET['id'];
if($id){
    $cz = $DB->get_row("SELECT * FROM `kmtype` WHERE `id` = '$id'");
    $rmb=$cz['km_rmb'];
}else{
    exit("<script language='javascript'>alert('这里是支付提交页面，你走错了！');window.location.href='/daili/login.php';</script>");
}
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            在线充值
                        </div>
                        
                        <div class="panel-body">
                            
                            <div class="row">
                                <div class="col-sm-12">
                                    
                                    <form action="/pay/alipayapi.php" class="alipayform validate" method="post" target="_blank">
                                    <ul class="list-group list-group-minimal">
                                        <li class="list-group-item">
                                            <?php
                                            $d=time();
                                            ?>
                                            <span class="badge badge-roundless badge-warning"><?php echo "" . date("Ymdhis", $d);?></span>
                                            <input type="text" name="WIDout_trade_no" id="out_trade_no" value="<?php echo "" . date("Ymdhis", $d);?>" class="hide">
                                            订单号
                                        </li>
                                        <li class="list-group-item">
                                            <span class="badge badge-roundless badge-info">代理充值余额</span>
                                            <input type="text" name="WIDsubject" value="代理充值余额" class="hide">
                                            商品名称
                                        </li>
                                        <li class="list-group-item">
                                            <span class="badge badge-roundless badge-danger"><?php echo $rmb?></span>
                                            <input type="text" name="WIDtotal_fee" value="<?php echo $rmb?>" class="hide">
                                            充值面额
                                        </li>
                                        <input type="text" name="WIDbody" value="<?php echo $dlid?>" class="hide">
                                    </ul>
                                    <button type="submit" class="btn btn-success btn-icon btn-block">
                                        <i class="fa-check"></i>
                                        <span>确认支付</span>
                                    </button>
                                    </form>
                                    
                                </div>
                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<?php  