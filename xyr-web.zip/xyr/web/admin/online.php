<?php
$mod='blank';
include("../api.inc.php");
$title='当前在线用户';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/openvpn-status.txt';
        $file2 = 'http://'.$rs['ipport'].'/udp/openvpn-status-udp.txt';
    }
}else{
    $file = '../res/openvpn-status.txt';
    $file2 = '../udp/openvpn-status-udp.txt';
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以看到在线用户使用详细，刷新速度为你搭建时设置的时段</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">平台共有 
                    <?php
                    //在线人数接口udp
                    $str=file_get_contents($file,false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                    $onlinenum_udp = (int)((substr_count($str,date('Y'))-1)/2);

                    //在线人数接口tcp
                    $str=file_get_contents($file2,false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                    $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);
                    ?><?php echo round($onlinenum_udp+$onlinenum)?>
                                           人在线</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
                      <div class="row">
                          <div class="col-sm-6">
                            <div class="table-responsive">
                            
                                        <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                      <th>TCP协议-ID</th>
                                                      <th data-priority="1">用户名</th>
                                                      <th data-priority="3">上传</th>
                                                      <th data-priority="6">下载</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                  $str=file_get_contents($file);
                                                  $num=(substr_count($str,date('Y'))-1)/2;
                                                  $fp=fopen($file,"r");
                                                  fgets($fp);
                                                  fgets($fp);
                                                  fgets($fp);
                                                  for($i=0;$i<$num;$i++){
                                                  $j=$i+1;
                                                  echo "<tr>";
                                                      $line=fgets($fp);
                                                      $arr=explode(",",$line);
                                                      $recv=round($arr[2]/1024)/1000;
                                                      $sent=round($arr[3]/1024)/1000;
                                                      echo "<th>".$j."</th>";
                                                  echo "<td>".$arr[0]."</td>";
                                                  echo "<td>".$recv."MB</td>";
                                                  echo "<td>".$sent."MB</td>";
                                                  echo "</tr>";
                                                  }
                                                  ?>
                                            </tbody>
                                        </table>
                            
                            </div>
                          </div>
                          <div class="col-sm-6">
                            <div class="table-responsive">
                            
                                        <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                      <th>UDP协议-ID</th>
                                                      <th data-priority="1">用户名</th>
                                                      <th data-priority="3">上传</th>
                                                      <th data-priority="6">下载</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                  <?php
                                                  $str2=file_get_contents($file2);
                                                  $num=(substr_count($str2,date('Y'))-1)/2;
                                                  $fp=fopen($file2,"r");
                                                  fgets($fp);
                                                  fgets($fp);
                                                  fgets($fp);
                                                  for($i=0;$i<$num;$i++){
                                                  $j=$i+1;
                                                  echo "<tr>";
                                                      $line=fgets($fp);
                                                      $arr=explode(",",$line);
                                                      $recv=round($arr[2]/1024)/1000;
                                                      $sent=round($arr[3]/1024)/1000;
                                                      echo "<th>".$j."</th>";
                                                  echo "<td>".$arr[0]."</td>";
                                                  echo "<td>".$recv."MB</td>";
                                                  echo "<td>".$sent."MB</td>";
                                                  echo "</tr>";
                                                  }
                                                  ?>
                                            </tbody>
                                        </table>
                            
                            </div>
                          </div>

                      </div>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>


    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 