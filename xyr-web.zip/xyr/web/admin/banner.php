<?php
/**
 * 大图设置
**/
$mod='blank';
include("../api.inc.php");
$title='大图设置';
$bn=$DB->get_row("SELECT * FROM banner");
$img1=$bn['img1'];
$tit1=$bn['tit1'];
$info1=$bn['info1'];
$img2=$bn['img2'];
$tit2=$bn['tit2'];
$info2=$bn['info2'];
$img3=$bn['img3'];
$tit3=$bn['tit3'];
$info3=$bn['info3'];
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">更新官网的首页三个幻灯片</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                <div class="alert alert-info">
                    <button type="button" class="close" data-dismiss="alert">
                      <span aria-hidden="true">×</span>
                      <span class="sr-only">Close</span>
                    </button>
                    <strong>重要：</strong> 默认幻灯片ID必须是0，请勿修改删除！
                  </div>
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请输入内容进行更新</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">
<div class="alert alert-default">
<button type="button" class="close" data-dismiss="alert">
  <span aria-hidden="true">×</span>
  <span class="sr-only">Close</span>
</button>
图片和软件都是通过第三方平台上传后，复制文件地址粘贴至文本框即可
<br><br>
<span class="input-group-btn" style="display: inline-table;">
  <button type="button" class="btn btn-purple dropdown-toggle" data-toggle="dropdown">
    图片上传平台 <span class="caret"></span>
  </button>
  <ul class="dropdown-menu dropdown-purple no-spacing">
    <li><a target="_blank" href="https://www.niupic.com/">牛图网</a></li>
    <li><a target="_blank" href="http://img.hoop8.com/index.php">Hoop8</a></li>
    <li><a target="_blank" href="http://chuantu.biz/">Chuantu.biz</a></li>
  </ul>
</span>
<span class="input-group-btn" style="display: inline-table;">
  <button type="button" class="btn btn-red dropdown-toggle" data-toggle="dropdown">
    APP上传平台 <span class="caret"></span>
  </button>
  <ul class="dropdown-menu dropdown-red no-spacing">
    <li><a target="_blank" href="http://fir.im/">fir.im</a></li>
    <li><a target="_blank" href="http://pre.im/">pre.im</a></li>
    <li><a target="_blank" href="https://www.pgyer.com/">蒲公英</a></li>
  </ul>
</span>
</div>
<?php

$my=$_POST['my'];
if($my=='config'){
echo '<div class="alert';
$img1_c=$_POST['img1'];
$tit1_c=$_POST['tit1'];
$info1_c=$_POST['info1'];
$img2_c=$_POST['img2'];
$tit2_c=$_POST['tit2'];
$info2_c=$_POST['info2'];
$img3_c=$_POST['img3'];
$tit3_c=$_POST['tit3'];
$info3_c=$_POST['info3'];
$sql=$DB->query("UPDATE `banner` SET `img1` = '$img1_c',`tit1` = '$tit1_c',`info1` = '$info1_c',`img2` = '$img2_c',`tit2` = '$tit2_c',`info2` = '$info2_c',`img3` = '$img3_c',`tit3` = '$tit3_c',`info3` = '$info3_c' WHERE `banner`.`id` = 0");
  
if($sql){echo ' alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存成功！';}
else{echo ' alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>保存失败！';}
echo '</div>';
//echo $img1_c;
//exit;
echo "<style>#banner{display: none;}</style>";
}

 ?>

              <form id="banner" action="./banner.php" method="post" role="form" class="form-horizontal validate">
                
                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">大图设置1</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">1920px*1282px</span>
                      <input type="text" class="form-control" value="<?php echo $img1;?>" name="img1" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $img1;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">标题</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $tit1;?>" name="tit1" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">描述</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $info1;?>" name="info1" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">大图设置2</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">1920px*1282px</span>
                      <input type="text" class="form-control" value="<?php echo $img2;?>" name="img2" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $img2;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">标题</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $tit2;?>" name="tit2" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">描述</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $info2;?>" name="info2" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group-separator"></div>

                <div class="form-group">
                  <input type="hidden" name="my" value="config"/>
                  <label class="col-sm-2 control-label">大图设置3</label>
                  <div class="col-sm-10">
                    <div class="input-group">
                      <span class="input-group-addon">1920px*1282px</span>
                      <input type="text" class="form-control" value="<?php echo $img3;?>" name="img3" data-validate="required,url">
                      <span class="input-group-addon"><a target="_blank" href="<?php echo $img3;?>"><i class="linecons-search"></i></a></span>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">标题</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $tit3;?>" name="tit3" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-10">
                    <div class="input-group">
                        <span class="input-group-addon">描述</span>
                        <input type="text" class="form-control" id="field-1" value="<?php echo $info3;?>" name="info3" data-validate="required">
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <label class="col-sm-2 control-label"></label>
                  <div class="col-sm-6">
                    <button type="submit" type="button" class="btn btn-info">保存</button>
                  </div>
                </div>
                
              </form> 
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 