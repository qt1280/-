<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='搜索商品';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以检索内容</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">输入信息搜索</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                      <form action="./kmlist.php" method="get" role="form" class="form-inline validate">  
                        <div class="form-group">

                        <div class="form-group">

                          <select class="form-control" name="type">
                            <option value="1">卡密</option>
                            <option value="2">账号</option>
                          </select>
                            
                        </div>

                        <div class="form-group">
                          <input type="text" class="form-control" size="25" placeholder="内容" name="kw"  data-validate="required"/>
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 