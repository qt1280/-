<?php
/**
 * 搜索授权
**/
$mod='blank';
include("../api.inc.php");
$title='套餐管理';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            <p>提示：请你添加套餐后即可生成商品，如不可添加套餐，为固定套餐销售模式</p>
            <br />

            <div class="row">
                
                <div class="col-sm-12">
                    
<?php
//判断设置
$rs=$DB->get_row("SELECT * FROM auth_config");
$kmtype_con=$rs['kmtype'];
if($kmtype_con==1){
  echo "<style>#type_add, .type_del{display: none;}</style>";
  $dlid="0";
};
if($kmtype_con==0){
  if($_POST['name']){
  echo '';
  $name = daddslashes($_POST['name']);
  $days = daddslashes($_POST['days']);
  $maxll = daddslashes($_POST['maxll'])*1024*1024;
  $km_rmb = daddslashes($_POST['km_rmb']);
  if(!$DB->get_row("select * from `kmtype` where `name`='$name' limit 1")){
    $sql="insert into `kmtype` (`name`,`days`,`maxll`,`km_rmb`,`dlid`) values ('{$name}','{$days}','{$maxll}','{$km_rmb}','{$dlid}')";
    if($DB->query($sql))
      echo '<div class="alert alert-success">
                      <button type="button" class="close">
                        <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                        <span class="sr-only">Close</span>
                      </button>
                    成功添加一个套餐</div>
                  <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                    <i class="fa-edit"></i>
                    <span>继续添加</span>
                  </a>
                  <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                    <i class="fa-list-ol"></i>
                    <span>查看列表</span>
                  </a>
                    <style>#addtype{display: none;}</style>';
    else
      echo '<div class="alert alert-danger">
                      <button type="button" class="close">
                        <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                        <span class="sr-only">Close</span>
                      </button>添加失败：'.$DB->error().'</div>
                  <a href="javascript:history.go(-1)" class="btn btn-secondary btn-icon btn-icon-standalone">
                    <i class="fa-edit"></i>
                    <span>继续添加</span>
                  </a>
                  <a href="kmtype.php" class="btn btn-info btn-icon btn-icon-standalone">
                    <i class="fa-list-ol"></i>
                    <span>查看列表</span>
                  </a>
                  <style>#addtype{display: none;}</style>';
  }else{
    echo "<script>alert('该套餐已存在！');history.go(-1);</script>";
  }
  echo '';
  //exit;
  }
};

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
  if($kmtype_con==0){
      echo '<div class="alert';
      $id=$_GET['id'];
      $sql=$DB->query("DELETE FROM `kmtype` WHERE id='$id'");
      if($sql){echo ' alert-success">
                                              <button type="button" class="close">
                                                  <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                  <span class="sr-only">Close</span>
                                              </button>删除成功！';}
      else{echo ' alert-danger">
                                              <button type="button" class="close">
                                                  <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                  <span class="sr-only">Close</span>
                                              </button>删除失败！';}
      echo '</div><style>#addtype{display: none;}</style>';
      }else{
              echo "<script>alert('您没有权限删除！');history.go(-1);</script>";
            }
}
//echo "<script>alert('".$dlid."');</script>";
  $numrows=$DB->count("SELECT count(*) from `kmtype` WHERE `dlid`='$dlid'");
  $sql=" 1";
  $con='平台共有 '.$numrows.' 个套餐';

?>

                    <div id="addtype" class="panel panel-default">
                        <div class="panel-heading">
                            <?php echo $con; ?>
                        </div>
                        
                        <div class="panel-body">
                            
                            <form action="kmtype.php?my=add" method="POST" class="form-inline validate" style="overflow: hidden;" id="type_add">
                            <a href="kmlist.php" class="btn btn-info">商品列表</a>

                            
                            <div class="form-group pull-right">
                              <div class="form-group">
                                <input type="text" class="form-control" name="name" placeholder="套餐名称" data-validate="required">
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control" name="days" placeholder="使用天数" data-validate="required,number,min[1]">
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control" name="maxll" placeholder="流量（GB）" data-validate="required,number,min[1]">
                              </div>
                              <div class="form-group">
                                <input type="text" class="form-control" name="km_rmb" placeholder="售价" data-validate="required,number,min[1]">
                              </div>
                              <button type="submit" class="btn btn-secondary btn-single">添加套餐</button>
                            </div>
                            </form>

                            <br>

                            <div id="addtype_list" class="row">
                                                <?php

                                                $rs=$DB->query("SELECT * FROM `kmtype` WHERE `dlid` = '$dlid' and i='0'");
                                                while($res = $DB->fetch($rs))
                                                { ?>

                                                <div class="col-sm-4">
                                                  <div class="xe-widget xe-todo-list xe-todo-list-turquoise">
                                                    <div class="xe-header">
                                                      <div class="xe-icon">
                                                        <i class="fa-credit-card"></i>
                                                      </div>
                                                      <div class="xe-label">
                                                        <strong><?=$res['name']?></strong>
                                                      </div>
                                                        <div class="xe-nav text-right type_del">
                                                          <a href="kmtype.php?my=del&id=<?=$res['id']?>" onclick="if(!confirm('你确实要删除此套餐吗？')){return false;}" class="xe-next" style="color: rgba(255, 255, 255, 0.50);">
                                                            <i class="fa-close"></i>
                                                          </a>
                                                        </div>
                                                    </div>
                                                    <div class="xe-body">
                                                      
                                                      <ul class="list-unstyled">
                                                        <li>
                                                          <label>
                                                            <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                            <span><?=$res['days']?>天使用时间</span>
                                                          </label>
                                                        </li>
                                                        <li>
                                                          <label>
                                                            <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                            <span><?=round(($res['maxll'])/1024/1024)?>GB流量</span>
                                                          </label>
                                                        </li>
                                                        <li>
                                                          <label>
                                                            <div class="cbr-replaced cbr-checked cbr-turquoise"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked=""></div><div class="cbr-state"><span></span></div></div>
                                                            <span><?=$res['km_rmb']?>元</span>
                                                          </label>
                                                        </li>
                                                      </ul>
                                                      
                                                    </div>
                                                    <div class="xe-footer">
                                                      <form action="kmlist.php?my=add" method="POST" class="form-inline validate">
                                                          <input type="text" class="hide" name="kmtype_id" value="<?=$res['id']?>" data-validate="required,number,min[1]">
                                                          <input type="text" class="hide" name="value" value="<?=$res['days']?>" data-validate="required,number,min[1]">
                                                          <input type="text" class="hide" name="values" value="<?=round(($res['maxll'])/1024/1024)?>" data-validate="required,number,min[1]">
                                                         <div class="form-group">
                                                            <input type="text" class="form-control" name="num" placeholder="开多少张卡？" data-validate="required,number,min[1]">
                                                          </div>
                                                         <div class="form-group">
                                                             <button type="submit" class="btn btn-white btn-single btn-block">生成</button>
                                                          </div>
                                                      </form>
                                                    </div>
                                                  </div>
                                                </div>

                                                <?php }
                                                ?>


                            </div>
                            
                        </div>
                        
                    </div>
                </div>

            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<?php  