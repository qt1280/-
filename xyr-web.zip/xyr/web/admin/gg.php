<?php
/**
 * 公告设置
**/
$mod='blank';
include("../api.inc.php");
$title='公告设置';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">此处可以设置默认安卓APP首页</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title">请输入信息</h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">



<?php
if($_POST['mo']){
echo '<div class="alert '; 

$name="gg";
$mo = $_REQUEST['mo'];   
@$fp=fopen("../$name.txt","w");
fwrite($fp,"$mo");
$filename = "$name.txt";

if($fp)
echo 'alert-success">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>成功修改默认公告</div>
                <a href="gg.php" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续修改</span>
                </a>
                <style>#gg{display: none;}</style>'; 
else
                echo 'alert-danger">
                    <button type="button" class="close">
                      <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                      <span class="sr-only">Close</span>
                    </button>
                  添加失败</div>
                <a href="gg.php" class="btn btn-secondary btn-icon btn-icon-standalone">
                  <i class="fa-edit"></i>
                  <span>继续修改</span>
                </a>
                <style>#gg{display: none;}</style>'; 
//exit;  
}
?>


                    <form id="gg" action="./gg.php" method="post" class="form-horizontal validate" role="form">
                      <div class="form-group">
                        <label class="col-sm-2 control-label">首页公告：</label>
                        <div class="col-sm-9">
                           <textarea class="form-control" cols="5" id="field-5" name="mo" rows="6" data-validate="required"><?php
                                $myfile = fopen("../gg.txt", "r") or die("没有找到gg.txt，请在流控根目录创建，并且赋予777权限!");
                                echo fread($myfile,filesize("../gg.txt"));
                                fclose($myfile);
                                ?></textarea>
                        </div>
                      </div>  
 
                      <div class="form-group">
                        <label class="col-sm-2 control-label"></label>
                        <div class="col-sm-9">
                          <button type="submit" type="button" class="btn btn-info btn-block">修改</button>
                        </div>
                      </div>
                    </form>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 