<?php
/**
 * 登录后台
**/
 error_reporting(E_ALL); 
$mod='blank';
include("../api.inc.php");
if(isset($_POST['user']) && isset($_POST['pass'])){
  $user=daddslashes($_POST['user']);
  $pass=md5(daddslashes($_POST['pass']));
  $row = $DB->get_row("SELECT * FROM auth_user WHERE user='$user' limit 1");
  if($user==$adminuser && $pass==$adminpass) {
    $session=md5($user.$pass.$password_hash);
    $token=authcode("{$user}\t{$session}", 'ENCODE', SYS_KEY);
    setcookie("ol_token", $token, time() + 604800);
    @header('Content-Type: text/html; charset=UTF-8');
    exit("<script language='javascript'>alert('登录成功！');window.location.href='index.php';</script>");
  }elseif ($pass != $row['pass']) {
    @header('Content-Type: text/html; charset=UTF-8');
    exit("<script language='javascript'>alert('用户名或密码不正确！');history.go(-1);</script>");
  }
}elseif(isset($_GET['logout'])){
  setcookie("ol_token", "", time() - 604800);
  @header('Content-Type: text/html; charset=UTF-8');
  exit("<script language='javascript'>alert('您已成功注销本次登录！');window.location.href='./login.php';</script>");
}elseif($islogin2==1){
  exit("<script language='javascript'>alert('您已登录！');window.location.href='index.php';</script>");
}

?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body login-page login-light">

    
    <div class="login-container">
    
        <div class="row">
        
            <div class="col-sm-6 col-sm-offset-3">
            
                <script type="text/javascript">
                    jQuery(document).ready(function($)
                    {
                        // Reveal Login form
                        setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
                        
                        
                        // Validation and Ajax action
                        $("form#login").validate({
                            rules: {
                                user: {
                                    required: true
                                },
                                
                                pass: {
                                    required: true
                                }
                            },
                            
                            messages: {
                                user: {
                                    required: '此为必填项！'
                                },
                                
                                pass: {
                                    required: '此为必填项！'
                                }
                            },
                            
                        });
                        
                        // Set Form focus
                        $("form#login .form-group:has(.form-control):first .form-control").focus();
                    });
                </script>
                
                <!-- Errors container -->
                <div class="errors-container">
                
                                    
                </div>

                <!-- Add class "fade-in-effect" for login form effect -->
                <form action="./login.php" method="post" role="form" id="login" class="login-form fade-in-effect">
                    
                    <div class="login-header">
                        <img src="../../assets/images/logo-white-bg@2x.png" alt="" width="140" />
                        <div class="label label-primary m-t-10">管理后台</div>
                    </div>
    
                    
                    <div class="form-group">
                        <label class="control-label" for="user">请输入管理员帐号</label>
                        <input type="text" class="form-control" name="user" id="user" autocomplete="off" />
                    </div>
                    
                    <div class="form-group">
                        <label class="control-label" for="pass">请输入管理员密码</label>
                        <input type="password" class="form-control" name="pass" id="pass" autocomplete="off" />
                    </div>
                    
                  <div class="form-group">
                    <label>
                      <input type="checkbox" class="cbr">
                      记住登录信息
                    </label>
                  </div>

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary  btn-block text-center">
                            <i class="fa-lock"></i>
                            马上登录
                        </button>
                    </div>

                    </div>
                    
                </form>
                
                
            </div>
            
        </div>
        
    </div>



    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>
    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>


    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 