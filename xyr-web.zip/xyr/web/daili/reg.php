<?php
/**
 * 代理注册
**/
$mod='blank';
include("../api.inc.php");
$dlconfig=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$tj_user=$_REQUEST['tj_user'];
if(isset($_POST['user']) && isset($_POST['pass'])){
    //JXL_add for 2016-04-16 begin
    $tj_user=$_REQUEST['tj_user_c'];
    //echo "<script language='javascript'>alert('".$tj_user."');</script>";
    //JXL_add for 2016-04-16 end
    $user=daddslashes($_POST['user']);
    $pass=daddslashes($_POST['pass']);
    $name=daddslashes($_POST['name']);
    $tel=daddslashes($_POST['tel']);
    $qq=daddslashes($_POST['qq']);
    $verifycode=daddslashes($_POST['verifycode']);
    $row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
    $dlid=$row['id'];
    if($dlconfig['regok']==0){
    if($row['active']=="0" or $dlid<>""){
        exit("<script language='javascript'>alert('代理用户已经注册但未激活，请联系管理员激活！');window.location.href='./login.php';</script>");
    }
    if($user && $pass){
        if(!is_username($user)){
            exit("<script language='javascript'>alert('用户名只能是2~20位的字母数字！');history.go(-1);</script>");
        }elseif(!$verifycode || $verifycode!=$_SESSION['verifycode']){
            exit("<script language='javascript'>alert('验证码不正确！');history.go(-1);</script>");
        }elseif($dlconfig['activeok']==0){
            /*JXL_add for 2016-04-16
            $DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$user','$pass','0',0,null,1,'$date');");
            */
            $DB->query("insert `auth_daili`(`id`,`tj_user`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`,`name`,`tel`,`qq`) values(null,'$tj_user','$user','$pass','0',0,null,1,'$date','$name','$tel','$qq');");
            $row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");

            //注册添加分站
            $rs_d=$DB->get_row("SELECT * FROM website");
            $logo=$rs_d['logo'];
            $webtitle=$name;
            $webqq=$qq;
            $webtel=$tel;
            $app1=$rs_d['app1'];
            $app2=$rs_d['app2'];
            $appleid1=$rs_d['appleid1'];
            $appleps1=$rs_d['appleps1'];
            $appleid2=$rs_d['appleid2'];
            $appleps2=$rs_d['appleps2'];
            $appleid3=$rs_d['appleid3'];
            $appleps3=$rs_d['appleps3'];
            $and_img1=$rs_d['and_img1'];
            $and_img2=$rs_d['and_img2'];
            $and_img3=$rs_d['and_img3'];
            $and_img4=$rs_d['and_img4'];
            $jia1=$rs_d['jia1'];
            $jia2=$rs_d['jia2'];
            $jia3=$rs_d['jia3'];
            $jia4=$rs_d['jia4'];
            $daili=$row['id'];
            $webname=$user;
            //echo "<script language='javascript'>alert('".$daili."');</script>";
            $DB->query("insert into `website` (`logo`, `title`, `app1`, `app2`, `qq`, `tel`, `appleid1`, `appleps1`, `appleid2`, `appleps2`, `appleid3`, `appleps3`, `and_img1`, `and_img2`, `and_img3`, `and_img4`, `jia1`, `jia2`, `jia3`, `jia4`, `daili`, `name`) values ('$logo','$webtitle','$app1','$app2','$webqq','$webtel','$appleid1','$appleps1','$appleid2','$appleps2','$appleid3','$appleps3','$and_img1','$and_img2','$and_img3','$and_img4','$jia1','$jia2','$jia3','$jia4','$daili','$webname')");

            //赠送金额给推荐人
            $rs=$DB->get_row("SELECT * FROM auth_config");
            $daili_cash_con=$rs['daili_cash'];
            $rs2=$DB->get_row("SELECT * FROM auth_daili where `user`='{$tj_user}'");
            $tj_rmb=round($rs2['tj_rmb']+$daili_cash_con);
            //echo "<script language='javascript'>alert('返现为：".$daili_cash_con."');</script>";
            //echo "<script language='javascript'>alert('该代理已有的返现金额：".$tj_rmb."');</script>";
            //echo "<script language='javascript'>alert('加起来".$tj_rmb."');</script>";
            $sql=$DB->query("update `auth_daili` set `tj_rmb`='$tj_rmb' where `user`='{$tj_user}'");

            if($row['id']){
                unset($_SESSION['verifycode']);
                exit("<script language='javascript'>alert('注册成功，账号已经激活，请联系管理员充值使用！');window.location.href='./login.php';</script>");    
            }else{
                exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
            }
        }else{
            /*JXL_add for 2016-04-16
            $DB->query("insert `auth_daili`(`id`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`) values(null,'$user','$pass','0',0,null,0,'$date');");
            */
            $DB->query("insert `auth_daili`(`id`,`tj_user`,`user`,`pass`,`rmb`,`vip`,`kmlist`,`active`,`regdate`,`name`,`tel`,`qq`) values(null,'$tj_user','$user','$pass','0',0,null,1,'$date','$name','$tel','$qq');");
            $row = $DB->get_row("SELECT * FROM auth_daili WHERE user='$user' limit 1");
            if($row['id']){
                unset($_SESSION['verifycode']);
                exit("<script language='javascript'>alert('注册成功，请联系管理员激活！');window.location.href='./login.php';</script>"); 
            }else{
                exit("<script language='javascript'>alert('注册失败，请联系管理员！');history.go(-1);</script>");
            }
        }
    }
}else{
    exit("<script language='javascript'>alert('网站已经关闭注册，请联系管理员注册！');window.location.href='./login.php';</script>");
}
}
    

$title='代理注册';
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body login-page login-light">
<?php
/*$tj_user=$_REQUEST['tj_user'];
echo $tj_user;*/
?>
    
    <div class="login-container">
    
        <div class="row">
        
            <div class="col-sm-6 col-sm-offset-3">
            
                <script type="text/javascript">
                    jQuery(document).ready(function($)
                    {
                        // Reveal Login form
                        setTimeout(function(){ $(".fade-in-effect").addClass('in'); }, 1);
                        
                        
                        // Validation and Ajax action
                        $("form#login").validate({
                            rules: {
                                user: {
                                    required: true
                                },
                                
                                pass: {
                                    required: true
                                },

                                name: {
                                    required: true
                                },

                                tel: {
                                    required: true
                                },

                                qq: {
                                    required: true
                                },
                                
                                verifycode: {
                                    required: true
                                }
                            },
                            
                            messages: {
                                user: {
                                    required: '此为必填项！'
                                },
                                
                                pass: {
                                    required: '此为必填项！'
                                },

                                name: {
                                    required: '此为必填项！'
                                },

                                qq: {
                                    required: '此为必填项！'
                                },
                                pass: {
                                    required: '此为必填项！'
                                },
                                
                                verifycode: {
                                    required: '请填写！'
                                }
                            },
                            
                        });
                        
                        // Set Form focus
                        $("form#login .form-group:has(.form-control):first .form-control").focus();
                    });
                </script>
                
                <!-- Errors container -->
                <div class="errors-container">
                
                                    
                </div>
                
                <!-- Add class "fade-in-effect" for login form effect -->
                <form action="./reg.php?tj_user_c=<?php echo $tj_user;?>" method="post" role="form" id="login" class="login-form fade-in-effect">
                    
                    <?php
                    $rs=$DB->get_row("SELECT * FROM website");
                    $logo=$rs['logo'];
                    ?>
                    <div class="login-header">
                        <img src="<?php echo $logo ?>" alt="" width="80" />
                        <div class="label label-primary m-t-10">代理注册</div>
                    </div>
    
                    
                    <div class="form-group">
                        <label class="control-label" for="user">请输入您的帐号</label>
                        <input type="text" class="form-control" name="user" id="user" autocomplete="off" />
                    </div>
                    
                    <div class="form-group">
                        <label class="control-label" for="pass">请输入您的密码</label>
                        <input type="password" class="form-control" name="pass" id="pass" autocomplete="off" />
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="name">请输入您的昵称</label>
                        <input type="text" class="form-control" name="name" id="name" autocomplete="off" />
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="qq">请输入您的QQ</label>
                        <input type="text" class="form-control" name="qq" id="qq" autocomplete="off" />
                    </div>

                    <div class="form-group">
                        <label class="control-label" for="tel">请输入您的电话</label>
                        <input type="text" class="form-control" name="tel" id="tel" autocomplete="off" />
                    </div>

                    <div class="form-group">
                                <label class="control-label" for="verifycode">验证码</label>
                                <input type="text" id="verifycode" name="verifycode" class="form-control" placeholder="验证码" required="required" style="max-width: 65%;display:inline-block;"/>&nbsp;<img title="点击刷新" src="../verifycode.php" onclick="this.src='../verifycode.php?'+Math.random();" style="max-height:32px;vertical-align:middle;" class="img-rounded">
                            </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn btn-purple  btn-block text-center">
                            <i class="fa-lock"></i>
                            立即注册
                        </button>
                    </div>
                    
                </form>
                
                <!-- External login -->
                <div class="external-login">
                    <a href="login.php" class="btn btn-turquoise text-center">
                        <i class="fa-edit"></i>
                        已经有账号？立即登录吧！
                    </a>
                    
                    <!-- 
                    <a href="#" class="twitter">
                        <i class="fa-twitter"></i>
                        Login with Twitter
                    </a>
                    
                    <a href="#" class="gplus">
                        <i class="fa-google-plus"></i>
                        Login with Google Plus
                    </a>
                     -->
                </div>
                
            </div>
            
        </div>
        
    </div>



    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>
    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>
    
    <script src="../assets/js/select2/select2.min.js"></script>
    <script src="../assets/js/jquery-ui/jquery-ui.min.js"></script>
    <script src="../assets/js/selectboxit/jquery.selectBoxIt.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<?php footer(); ?><?php 