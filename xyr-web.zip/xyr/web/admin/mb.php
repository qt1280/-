<?php
$mod='blank';
include("../api.inc.php");
$title='流量';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
if(isset($_GET['id'])){
    $id = $_GET['id'];
    $rs = $DB->get_row("SELECT * FROM `auth_fwq` WHERE `id`='$id' limit 1");
    if(!$rs){
        echo "此服务器不存在";
    }else{
        $file = 'http://'.$rs['ipport'].'/res/openvpn-status.txt';
        $file2 = 'http://'.$rs['ipport'].'/udp/openvpn-status-udp.txt';
    }
}else{
    $file = '../res/openvpn-status.txt';
    $file2 = '../udp/openvpn-status-udp.txt';
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<style type="text/css">
.page-loading-overlay {
    background: #fff;
}
.loader-2:after {
    border: solid 1px #333
}
.page-body {
background: #fff;
overflow: hidden;
}
@media (max-width: 750px) {
.page-body {
overflow-y: scroll;
}
}
</style>
<body class="page-body">

    <script type="text/javascript">
        jQuery(document).ready(function($)
        {   


            // Pageviews Visitors Chart
            var i = 0,
                line_chart_data_source = [
                //{ id: ++i, part1: 4, part2: 2 },
                <?php
                $str=file_get_contents($file);
                $num=(substr_count($str,date('Y'))-1)/2;
                $fp=fopen($file,"r");
                fgets($fp);
                fgets($fp);
                fgets($fp);
                for($i=0;$i<$num;$i++){
                $j=$i+1;
                    $line=fgets($fp);
                    $arr=explode(",",$line);
                    $recv=round($arr[2]/1024)/1000;
                    $sent=round($arr[3]/1024)/1000;
                echo "{ id: ++i, part2: ".$recv.", part1: ";
                echo "".$sent."},";
                }
                ?>

            ];
            
            $("#pageviews-visitors-chart").dxChart({
                dataSource: line_chart_data_source,
                commonSeriesSettings: {
                    argumentField: "id",
                    point: { visible: true, size: 5, hoverStyle: {size: 7, border: 0, color: 'inherit'} },
                    line: {width: 1, hoverStyle: {width: 1}}
                },
                series: [
                    { valueField: "part1", name: "下载", color: "#68b828" },
                    { valueField: "part2", name: "上传", color: "#cdedb3" },
                ],
                legend: {
                    position: 'inside',
                    paddingLeftRight: 5
                },
                commonAxisSettings: {
                    label: {
                        visible: false
                    },
                    grid: {
                        visible: true,
                        color: '#f9f9f9'
                    }
                },
                valueAxis: {
                    max: 100
                },
                argumentAxis: {
                    valueMarginsEnabled: false
                },
            });
            
            // Pageviews Visitors Chart UDP
            var i = 0,
                line_chart_data_source = [
                //{ id: ++i, part1: 4, part2: 2 },
                <?php
                $str=file_get_contents($file2);
                $num=(substr_count($str,date('Y'))-1)/2;
                $fp=fopen($file2,"r");
                fgets($fp);
                fgets($fp);
                fgets($fp);
                for($i=0;$i<$num;$i++){
                $j=$i+1;
                    $line=fgets($fp);
                    $arr=explode(",",$line);
                    $recv=round($arr[2]/1024)/1000;
                    $sent=round($arr[3]/1024)/1000;
                echo "{ id: ++i, part2: ".$recv.", part1: ";
                echo "".$sent."},";
                }
                ?>

            ];
            
            $("#pageviews-visitors-chart2").dxChart({
                dataSource: line_chart_data_source,
                commonSeriesSettings: {
                    argumentField: "id",
                    point: { visible: true, size: 5, hoverStyle: {size: 7, border: 0, color: 'inherit'} },
                    line: {width: 1, hoverStyle: {width: 1}}
                },
                series: [
                    { valueField: "part1", name: "下载", color: "#40bbea" },
                    { valueField: "part2", name: "上传", color: "#8bd4f0" },
                ],
                legend: {
                    position: 'inside',
                    paddingLeftRight: 5
                },
                commonAxisSettings: {
                    label: {
                        visible: false
                    },
                    grid: {
                        visible: true,
                        color: '#f9f9f9'
                    }
                },
                valueAxis: {
                    max: 100
                },
                argumentAxis: {
                    valueMarginsEnabled: false
                },
            });    
            
        });
        

        

        
        function between(randNumMin, randNumMax)
        {
            var randInt = Math.floor((Math.random() * ((randNumMax + 1) - randNumMin)) + randNumMin);
            
            return randInt;
        }
    </script>

    <div class="page-container">

            <div style="margin-left:-30px;">
                <div class="col-sm-6">
                    <?php
                    $str=file_get_contents($file);
                    $num=(substr_count($str,date('Y'))-1)/2;
                    $fp=fopen($file,"r");
                    fgets($fp);
                    fgets($fp);
                    fgets($fp);
                    for($i=0;$i<$num;$i++){
                    $j=$i+1;
                        $line=fgets($fp);
                        $arr=explode(",",$line);
                        $recv=round($arr[2]/1024)/1000;
                        $sent=round($arr[3]/1024)/1000;

                        $str=file_get_contents($file,false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                        $onlinenum = (int)((substr_count($str,date('Y'))-1)/2);

                        $mbs=$recv+$sent;
                        $zmbs=$mbs/$onlinenum;
                        /*echo "".$j."<br>";
                    echo "".$arr[0]."<br>";
                    echo "".$recv."<br>";
                    echo "".$sent."<br>";*/
                    }
                    ?>

                    <div class="chart-item-bg">
                        <div class="chart-label">
                            <div class="h3 text-secondary text-bold" data-count="this" data-from="0.00" data-to="<?php echo round($zmbs, 4);?>" data-suffix="mb/s" data-duration="1">00mb/s</div>
                            <span class="text-medium text-muted">TCP协议上传和下载平均流量数据图谱</span>
                        </div>
                        <div id="pageviews-visitors-chart" style="height: 320px;"></div>
                    </div>
                </div>
                <div class="col-sm-6">
                    <?php
                    $str=file_get_contents($file2);
                    $num=(substr_count($str,date('Y'))-1)/2;
                    $fp=fopen($file2,"r");
                    fgets($fp);
                    fgets($fp);
                    fgets($fp);
                    for($i=0;$i<$num;$i++){
                    $j=$i+1;
                        $line=fgets($fp);
                        $arr=explode(",",$line);
                        $recv=round($arr[2]/1024)/1000;
                        $sent=round($arr[3]/1024)/1000;

                        $str=file_get_contents($file2,false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                        $onlinenum_udp = (int)((substr_count($str,date('Y'))-1)/2);

                        $mbs=$recv+$sent;
                        $zmbs2=$mbs/$onlinenum_udp;
                        /*echo "".$j."<br>";
                    echo "".$arr[0]."<br>";
                    echo "".$recv."<br>";
                    echo "".$sent."<br>";*/
                    }
                    ?>

                    <div class="chart-item-bg">
                        <div class="chart-label">
                            <div class="h3 text-info text-bold" data-count="this" data-from="0.00" data-to="<?php echo round($zmbs2, 4);?>" data-suffix="mb/s" data-duration="1">00mb/s</div>
                            <span class="text-medium text-muted">UDP协议上传和下载平均流量数据图谱</span>
                        </div>
                        <div id="pageviews-visitors-chart2" style="height: 320px;"></div>
                    </div>
                </div>
            </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>

    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 