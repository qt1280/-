<?php
$mod='blank';
include("../api.inc.php");
$title='服务器列表';
if($islogin2==1){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head.php';?>
<body class="page-body">

    <?php include 'set.php';?>
    
    <div class="page-container">

        <?php include 'nav.php';?>
        
        <div class="main-content">
                    
            <?php include 'info.php';?>
            
          <div class="page-title">
          <div class="title-env">
            <h1 class="title"><?php echo $title ?></h1>
            <p class="description">提示：请自行设置对应服务器IP和端口，保证流控首页正常读取流量信息；</p>
          </div>
            <div class="breadcrumb-env">
            
               <ol class="breadcrumb bc-1">
                 <li>
                  <a href="index.php"><i class="fa-home"></i>首页</a>
                </li>
                <li class="active">
                      <strong><?php echo $title ?></strong>
                  </li>
              </ol>
                  
             </div>
           </div>

<?php

$my=isset($_GET['my'])?$_GET['my']:null;

if($my=='del'){
echo '<div class="alert';
$id=$_GET['id'];
$sql=$DB->query("DELETE FROM `auth_fwq` WHERE id='$id'");
if($sql){echo ' alert-success">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除成功！';}
else{echo ' alert-danger">
                                        <button type="button" class="close">
                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                            <span class="sr-only">Close</span>
                                        </button>删除失败！';}
echo '</div>';
}

else
{
if(!empty($_GET['kw'])) {
  $sql=" `name`='{$_GET['kw']}'";
  $numrows=$DB->count("SELECT count(*) from `auth_fwq` WHERE{$sql}");
  $con='共有 '.$numrows.' 个服务器';
}else{
  $numrows=$DB->count("SELECT count(*) from `auth_fwq` WHERE 1");
  $sql=" 1";
  $con='共有 '.$numrows.' 个服务器';
}
?>

            <div class="row">
                <div class="col-sm-12">
                    
                  <div class="panel panel-default">
                    <div class="panel-heading">
                      <h3 class="panel-title"><?php echo $con; ?></h3>
                      
                      <div class="panel-options">
                        <a href="#">
                          <i class="linecons-cog"></i>
                        </a>
                        
                        <a href="#" data-toggle="panel">
                          <span class="collapse-icon">&ndash;</span>
                          <span class="expand-icon">+</span>
                        </a>
                        
                        <a href="#" data-toggle="reload">
                          <i class="fa-rotate-right"></i>
                        </a>
                        
                        <a href="#" data-toggle="remove">
                          &times;
                        </a>
                      </div>
                    </div>
                    <div class="panel-body">

                      <form action="fwqlist.php" method="get" role="form" class="form-inline">
                      <a href="addfwq.php" class="btn btn-info">添加服务器</a>
                      <a href="online.php" class="btn btn-blue">当前服务器在线用户</a>
                        
                        <div class="form-group pull-right">
                        <div class="form-group">
                          <input type="text" class="form-control" size="25" name="kw" placeholder="服务器名称">
                        </div>

                        <div class="form-group">
                          <button type="submit" class="btn btn-secondary btn-single">查询</button>
                        </div>
                        
                        </div>
                        
                      </form>

                      <div class="table-responsive">
                      
                                  <table cellspacing="0" class="table table-small-font table-bordered table-striped">
                                      <thead>
                                          <tr>
                                                <th>ID</th>
                                                <th data-priority="1">服务器名称</th>
                                                <th data-priority="3">地址</th>
                                                <th data-priority="6">在线人数</th>
                                                <th data-priority="6">添加时间</th>
                                                <th data-priority="6">操作</th>
                                          </tr>
                                      </thead>
                                      <tbody>
                                          <?php
                                          $pagesize=30;
                                          $pages=intval($numrows/$pagesize);
                                          if ($numrows%$pagesize)
                                          {
                                           $pages++;
                                           }
                                          if (isset($_GET['page'])){
                                          $page=intval($_GET['page']);
                                          }
                                          else{
                                          $page=1;
                                          }
                                          $offset=$pagesize*($page - 1);
                                          $rs=$DB->query("SELECT * FROM `auth_fwq` WHERE{$sql} order by id desc limit $offset,$pagesize");
                                          while($res = $DB->fetch($rs))
                                          {
                                          $str=file_get_contents('http://'. $res['ipport'] .'/res/openvpn-status.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                          $str2=file_get_contents('http://'. $res['ipport'] .'/udp/openvpn-status-udp.txt',false,stream_context_create(array('http' => array('method' => "GET", 'timeout' => 1))));
                                          $onlinenum_tcp = (substr_count($str,date('Y'))-1)/2;
                                          $onlinenum_udp = (substr_count($str2,date('Y'))-1)/2;
                                          $onlinenum =$onlinenum_tcp+$onlinenum_udp;
                                          if($onlinenum < 0)
                                            $onlinetext = '<span style="color:red;">超时</span>';
                                          else
                                            $onlinetext = '<a href="online.php?id='.$res['id'].'">'.(int)$onlinenum.'</a>';
                                            $onlinetext2 = '<a class="btn btn-xs btn-secondary" href="online.php?id='.$res['id'].'">在线用户</a>';
                                          ?>
                                          <tr>
                                          <th><span class="co-name"><?=$res['id']?></span></th>
                                          <td><?=$res['name']?></td>
                                          <td><?=$res['ipport']?></td>
                                          <td><?=$onlinetext?></td>
                                          <td><?=$res['time']?></td>
                                          <td><?=$onlinetext2?>&nbsp;<a class="btn btn-xs btn-turquoise" href="./fwqset.php?id=<?=$res['id']?>">配置</a>&nbsp;<a href="./fwqlist.php?my=del&id=<?=$res['id']?>" class="btn btn-xs btn-danger" onclick="if(!confirm('你确实要删除此记录吗？')){return false;}">删除</a></td>
                                          </tr>

                                          <?php }
                                          ?>
                                      </tbody>
                                  </table>
                      
                      </div>
                      
                      <?php
                      echo'<ul class="pagination pagination-sm">';
                      $first=1;
                      $prev=$page-1;
                      $next=$page+1;
                      $last=$pages;
                      if ($page>1)
                      {
                      echo '<li><a href="fwqlist.php?page='.$first.$link.'">首页</a></li>';
                      echo '<li><a href="fwqlist.php?page='.$prev.$link.'">&laquo;</a></li>';
                      } else {
                      echo '<li class="disabled"><a>首页</a></li>';
                      echo '<li class="disabled"><a>&laquo;</a></li>';
                      }
                      for ($i=1;$i<$page;$i++)
                      echo '<li><a href="fwqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '<li class="disabled"><a>'.$page.'</a></li>';
                      for ($i=$page+1;$i<=$pages;$i++)
                      echo '<li><a href="fwqlist.php?page='.$i.$link.'">'.$i .'</a></li>';
                      echo '';
                      if ($page<$pages)
                      {
                      echo '<li><a href="fwqlist.php?page='.$next.$link.'">&raquo;</a></li>';
                      echo '<li><a href="fwqlist.php?page='.$last.$link.'">尾页</a></li>';
                      } else {
                      echo '<li class="disabled"><a>&raquo;</a></li>';
                      echo '<li class="disabled"><a>尾页</a></li>';
                      }
                      echo'</ul>';
                      #分页
                      }
                      ?>
                      
                    </div>
                  
                  </div>
                    
                </div>

            </div>
   
            <!-- Main Footer -->
            <?php include("../copy.php");?>
        </div>
        
        </div>
        
    </div>

    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>


    <!-- Imported scripts on this page -->
    <script src="../assets/js/xenon-widgets.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/globalize.min.js"></script>
    <script src="../assets/js/devexpress-web-14.1/js/dx.chartjs.js"></script>
    <script src="../assets/js/toastr/toastr.min.js"></script>


    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html><?php 