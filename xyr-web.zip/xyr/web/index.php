<?php
$mod='blank';
include("api.inc.php");
$title='';
?>
<!DOCTYPE html>
<html lang="en" style="overflow: hidden;">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="" />
  <meta name="author" content="" />

<?php
$name = daddslashes($_GET['i']);
  if($name){
    $rs=$DB->get_row("SELECT * FROM website where name = '$name'");
  }else{
    $name=xyr;
  };
?>
<?php
$url="http://".$_SERVER ['HTTP_HOST'].$_SERVER['PHP_SELF'];
preg_match("#http://(.([a-zA-Z]*?))\.#i",$url,$match);
//echo $match[1];
  if($match[1]=="www" or  $match[1]==""){
    $match[1]=xyr;
  }else{
  };
$weburl2="http://".$_SERVER ['HTTP_HOST']."/";
$rs2=$DB->get_row("SELECT * FROM website where name = '$match[1]'");
?>
<title><?php 
$webtitle=$rs['title']; 
if($webtitle==""){
  $rs3=$DB->get_row("SELECT * FROM website where name = 'xyr'");
  $webtitle=$rs3['title']; 
}
echo $webtitle; 
?> - 流量平台</title>
  <meta name="keywords" content="<?php $webtitle=$rs['title']; echo $webtitle; echo $rs2['title']; ?>,<?php $webtitle=$rs['title']; echo $webtitle; echo $rs2['title']; ?>广东流量,<?php $webtitle=$rs['title']; echo $webtitle; echo $rs2['title']; ?>全国流量特价,<?php $webtitle=$rs['title']; echo $webtitle; echo $rs2['title']; ?>流量包月,<?php $webtitle=$rs['title']; echo $webtitle; echo $rs2['title']; ?>4G流量" />
<?php
    $weburl = "http://".$_SERVER['HTTP_HOST']."/?i=";
   //echo $weburl;
?>
  <!-- <link rel="stylesheet" href="http://fonts.googleapis.com/css?family=Arimo:400,700,400italic">-->
  <link rel="stylesheet" href="../assets/css/fonts/linecons/css/linecons.css">
  <link rel="stylesheet" href="../assets/css/fonts/fontawesome/css/font-awesome.min.css">
  <link rel="stylesheet" href="../assets/css/bootstrap.css">
  <link rel="stylesheet" href="../assets/css/xenon-core.css">
  <link rel="stylesheet" href="../assets/css/xenon-forms.css">
  <link rel="stylesheet" href="../assets/css/xenon-components.css">
  <link rel="stylesheet" href="../assets/css/xenon-skins.css">
  <link rel="stylesheet" href="../assets/css/custom.css">
  <script src="../assets/js/jquery-1.11.1.min.js"></script>

  <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
  <!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
  <![endif]-->

</head>
<body>
    <iframe id="index" src=""  width="100%" height="100%" frameborder=0 scrolling=0 ></iframe>
<?php
    if ($match[1]) {
      $spweb = "http://".$_SERVER['HTTP_HOST']."/";
    }else{
      
    }
   //echo $weburl;
?>
    <script>
    try { if( self.location == "<?php echo $spweb?>" ) { 
    //top.location.href = "/web"; 
$("#index").attr("src","/web/index.php?name=<?php echo $match[1] ?>");
    } 
    else if( self.location == "<?php echo $weburl2;?>" ) { 
            $("#index").attr("src","/web/index.php?name=<?php echo $match[1] ?>");
    } 
    else if( self.location == "<?php echo $weburl;?><?php echo $name;?>" ) { 
            $("#index").attr("src","/web/index.php?name=<?php echo $name ?>");
    } 

    else {
    //document.write ("升级中......")
    //top.location.href = "/web"; 
    $("#index").attr("src","/web/?name=xyr");
    }} catch(e) {}</script> 
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>