<?php
$mod='blank';
include("../api.inc.php");
$title='账号列表';
$dlid=$_SESSION['dlid'];
if($dlid<>""){}else exit("<script language='javascript'>window.location.href='./login.php';</script>");
$row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
$rs=$DB->get_row("SELECT * FROM auth_config WHERE 1");
$vip=$row['vip'];
if($vip==1){
    $dljg=$rs['dl1'];
    $wx=$rs['wx1'];
}elseif($vip==2){
    $dljg=$rs['dl2'];
    $wx=$rs['wx2'];
}elseif($vip==3){
    $dljg=$rs['dl3'];
    $wx=$rs['wx3'];
}elseif($vip==0){
    $dljg=$rs['dl0'];
    $wx=$rs['wx0'];
    //exit("<script language='javascript'>window.location.href='./login.php';</script>");
}elseif($vip==4){
    $dljg=$rs['dl4'];
    $wx=$rs['wx4'];
}elseif($vip==5){
    $dljg=$rs['dl5'];
    $wx=$rs['wx5'];
}
?>
<!DOCTYPE html>
<html lang="en">
<?php include '../head2.php';?>
<body class="page-body">
    
    <?php include 'nav.php';?>

    <div class="page-container"><!-- add class "sidebar-collapsed" to close sidebar by default, "chat-visible" to make chat appear always -->
            
        <div class="main-content">
                    
            
            <h3 id="layout-toggles">
                代理中心
                <br />
            </h3>
            <p>
            <?php
                $row = $DB->get_row("SELECT * FROM auth_daili WHERE id='$dlid' limit 1");
                $dlrmb=$row['rmb'];
                echo '当前包月无限： '.$wx.'元/个，当前余额 '.$dlrmb.' 元'
            ?>
            </p>
            <br />

            <div class="row">
              <div class="col-sm-12">

<div class="alert alert-info">
  <button type="button" class="close" data-dismiss="alert">
    <span aria-hidden="true">×</span>
    <span class="sr-only">Close</span>
  </button>
  
  <strong>无限流量模式说明：</strong> 无限流量需人工激活使用，可以让会员登录会员中心自动激活，或者代理通过帐号列表点击激活！
</div>

                      </form>

                                  <?php

                                function getstr2($len, $chars=null)
                                {
                                  if(is_null($chars)){
                                    $chars = "0123456789";
                                  }
                                  mt_srand(10000000*(double)microtime());
                                  for($i = 0, $str = '', $lc = strlen($chars)-1; $i < $len; $i++){
                                    $str .= $chars[mt_rand(0, $lc)];  
                                  }
                                  return $str;
                                }
                                //echo getstr2(123);

                                //数量
                                $maxnum = $dlrmb/$wx;
                                $show_maxnum = intval($dlrmb/$wx);
                                if ($show_maxnum<1) {
                                  $show_maxnum=0;
                                }

                                //提示
                                $tip="<div class='alert alert-danger'>您的余额不足开账号，<a href='buy.php' style='color: #fff;'>请点击这里充值！</a></div><style>#pladd{display: none;}</style>";

                                  if($_POST['num']){



                                  $notes = daddslashes($_POST['notes']);
                                  $num = daddslashes($_POST['num']);
                                  $prefix = daddslashes($_POST['prefix']);
                                  $strlen = daddslashes($_POST['strlen']);
                                  $suffix = daddslashes($_POST['suffix']);
                                  $fwqid = "0";
                                  $pass = daddslashes($_POST['pass']);
                                  $maxll = 1000000*1024*1024;
                                  $state = "1";
                                  $tian = "31";
                                  $endtime = "";
                                  $by = "1";

                                    if($dlrmb<=$wx or $maxnum<$num){
                                        echo $tip;
                                    }else {

                                      for($x=0; $x<$num; $x++){

                                      $user = $prefix.getstr2($strlen).$suffix;

                                      if(!$DB->get_row("select * from `openvpn` where `iuser`='$user' limit 1")){
                                        $id=strtoupper(substr(md5($uin.time()),0,8).'-'.uniqid());
                                        $sql="insert into `openvpn` (`iuser`,`pass`,`isent`,`irecv`,`maxll`,`i`,`starttime`,`endtime`,`fwqid`,`notes`,`tian`,`dlid`,`by`) values ('{$user}','{$pass}',0,0,'{$maxll}','{$state}','".time()."','{$endtime}','{$fwqid}','{$notes}','{$tian}','{$dlid}','{$by}')";
                                        
                                        //扣款
                                        $rmb =$dlrmb-($num*$wx);
                                       // echo "<script language='javascript'>alert('".$rmb."');</script>";
                                        if($DB->query("UPDATE auth_daili SET rmb='{$rmb}' WHERE id='{$dlid}'")==true){
                                          /*echo '<div class="alert alert-success">
                                                              <button type="button" class="close" data-dismiss="alert">
                                                                <span aria-hidden="true">×</span>
                                                                <span class="sr-only">Close</span>
                                                              </button>成功扣款
                                                              '.$num*$wx.'，并生成帐号。
                                                              </div>
                                                              ';*/
                                        }
                                        if($DB->query($sql))
                                          echo "<div class='alert alert-success'>账号：{$user}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;密码：{$pass}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;激活天数：{$tian}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;备注：{$notes}</div><style>#pladd{display: none;}</style>";
                                        else
                                          echo '
                                                        <div class="alert alert-warning">
                                                          <button type="button" class="close">
                                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                            <span class="sr-only">Close</span>
                                                          </button>添加失败：'.$DB->error().'</div>
                                                          <style>#pladd{display: none;}</style>';
                                      }else{
                                        echo '
                                                        <div class="alert alert-danger">
                                                          <button type="button" class="close">
                                                            <span aria-hidden="true"><a href="javascript:history.go(-1)">×</a></span>
                                                            <span class="sr-only">Close</span>
                                                          </button>该账号已存在！</div>
                                                          <style>#pladd{display: none;}</style>';
                                      }


                                      }
                                    }

                                  }

                                  ?>

<?php
if($maxnum<1){
  echo $tip;
}
?>
                        <div id="pladd">
                            <ul class="nav nav-tabs">
                              <li class="active">
                                <a href="#home" data-toggle="tab">
                                  <span class="visible-xs"><i class="fa-android"></i></span>
                                  <span class="hidden-xs">添加包月帐号</span>
                                </a>
                              </li>
                            </ul>
                            
                            <div class="tab-content">

                              <div class="tab-pane active" id="home">

                                    <form action="./wx.php" method="post" role="form" class="form-horizontal validate">
                                      
                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账号个数</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="您可以开通<?php echo $show_maxnum; ?>个帐号" name="num" data-validate="required,number,max[<?php echo $show_maxnum; ?>],min[1]">
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号格式</label>
                                        <div class="col-sm-9">
                                          <div class="row">
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号前缀" name="prefix" data-validate="required">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="随机数长度，最少4位数" name="strlen" data-validate="required,number,min[4]">
                                            </div>
                                            <div class="col-sm-4">
                                              <input type="text" class="form-control" id="field-1" placeholder="账号后缀" name="suffix">
                                            </div>
                                          </div>
                                        </div>
                                      </div>

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">帐号密码</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入密码" name="pass" data-validate="required">
                                        </div>
                                      </div>  


                                      <div class="form-group">
                                        <label class="col-sm-2 control-label">账户备注</label>
                                        <div class="col-sm-9">
                                          <input type="text" class="form-control" id="field-1" placeholder="请输入备注" name="notes" value="包月无限">
                                        </div>
                                      </div>  

                                      <div class="form-group">
                                        <label class="col-sm-2 control-label"></label>
                                        <div class="col-sm-9">
                                          <button type="submit" type="button" class="btn btn-info btn-block">批量生成账号</button>
                                        </div>
                                      </div>
                                      
                                    </form>
                              </div>
                            </div>
                        
                        </div>
              </div>
            </div>

             <?php include("../copy2.php");?>
             
        </div>
        
    </div>
    
    <!-- Bottom Scripts -->
    <script src="../assets/js/bootstrap.min.js"></script>
    <script src="../assets/js/TweenMax.min.js"></script>
    <script src="../assets/js/resizeable.js"></script>
    <script src="../assets/js/joinable.js"></script>
    <script src="../assets/js/xenon-api.js"></script>
    <script src="../assets/js/xenon-toggles.js"></script>

    <script src="../assets/js/jquery-validate/jquery.validate.min.js"></script>

    <!-- JavaScripts initializations and stuff -->
    <script src="../assets/js/xenon-custom.js"></script>

</body>
</html>
<?php