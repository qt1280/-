<?php
$mysqlversion=$DB->count("select VERSION()");
$version = '../version.php';
$ver = include($version);   
?>
<div class="settings-pane">
            
        <a href="#" data-toggle="settings-pane" data-animate="true">
            ×
        </a>
        
        <div class="settings-pane-inner">
            
            <div class="row">
                
                <div class="col-md-4">
                    
                    <div class="user-info">
                        
                        <div class="user-image">
                            <a href="extra-profile.html">
                                <img src="../assets/images/user-2.png" class="img-responsive img-circle">
                            </a>
                        </div>
                        
                        <div class="user-details">
                            
                            <h3>
                                <a href="extra-profile.html"><?php echo $ver['vername'].' K'.$ver['ver']; ?></a>
                                
                                <!-- Available statuses: is-online, is-idle, is-busy and is-offline -->
                                <span class="user-status is-online hide"></span>
                            </h3>
                            
                            <p class="user-title">更新时间：<?php echo $ver['release']; ?></p>
                            
                            <div class="user-links">
                                <a href="extra-profile.html" class="btn btn-primary hide">Edit Profile</a>
                                <a target="_blank" href="http://www.xiaoyangren.net/" class="btn btn-success">升级版本</a>
                            </div>
                            
                        </div>
                        
                    </div>
                    
                </div>
                
                <div class="col-md-8 link-blocks-env">

                    <div class="links-block left-sep">
                        <h4>
                            <a href="#">
                                <span>相关页面</span>
                            </a>
                        </h4>
                        
                        <ul class="list-unstyled">
                            <li>
                                <a target="_blank" href="/web/">
                                    <i class="fa-angle-right"></i>
                                    官网首页
                                </a>
                            </li>
                            <li>
                                <a target="_blank" href="/user/login.php">
                                    <i class="fa-angle-right"></i>
                                    会员中心
                                </a>
                            </li>
                            <li>
                                <a target="_blank" href="/daili/">
                                    <i class="fa-angle-right"></i>
                                    代理中心
                                </a>
                            </li>
                            <li>
                                <a href="#">
                                    <i class="fa-angle-right"></i>
                                    数据库请自行查看路径
                                </a>
                            </li>
                        </ul>
                    </div>

                    <div class="links-block left-sep">
                        <h4>
                            <span>服务器状态</span>
                        </h4>

                        <ul class="list-unstyled">
                            <li>
                                <div class="cbr-replaced cbr-checked cbr-primary"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked="checked" id="sp-chk1"></div><div class="cbr-state"><span></span></div></div>
                                <label for="sp-chk1">PHP 版本：<?php echo phpversion() ?></label>
                            </li>
                            <li>
                                <div class="cbr-replaced cbr-checked cbr-primary"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked="checked" id="sp-chk2"></div><div class="cbr-state"><span></span></div></div>
                                <label for="sp-chk2">MySQL 版本：<?php echo $mysqlversion ?></label>
                            </li>
                            <li>
                                <div class="cbr-replaced cbr-checked cbr-primary"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked="checked" id="sp-chk3"></div><div class="cbr-state"><span></span></div></div>
                                <label for="sp-chk3">服务器软件：<?php echo $_SERVER['SERVER_SOFTWARE'] ?>； 文件上传许可：<?php echo ini_get('upload_max_filesize'); ?></label>
                            </li>
                            <li>
                                <div class="cbr-replaced cbr-checked cbr-primary"><div class="cbr-input"><input type="checkbox" class="cbr cbr-done" checked="checked" id="sp-chk4"></div><div class="cbr-state"><span></span></div></div>
                                <label for="sp-chk4">程序最大运行时间：<?php echo ini_get('max_execution_time') ?>s；  POST许可：<?php echo ini_get('post_max_size'); ?>； </label>
                            </li>
                        </ul>
                    </div>
                    
                </div>
                
            </div>
        
        </div>
        
    </div><?php 